# JET — Download at Full Speed. (Android App)

Complete Android Gradle project for **JET** with pre-configured **GitHub Actions** automatic APK build (`assembleDebug`).

## How to Auto-Build APK on GitHub
1. Extract this ZIP file (`JET-Android-GitHub.zip`).
2. Create a new repository on [GitHub](https://github.com/new) (e.g., `JET-Downloader`).
3. Upload all extracted files and folders (make sure the `.github/workflows/android-build.yml` folder is included!) and commit to `main`.
4. Open the **Actions** tab in your GitHub repository — **Build JET Android APK** starts automatically.
5. Once the green checkmark appears, click the workflow run and download **`JET-Android-Debug-APK`** from the **Artifacts** section.
