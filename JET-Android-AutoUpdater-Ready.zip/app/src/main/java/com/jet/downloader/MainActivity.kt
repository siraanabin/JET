package com.jet.downloader

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.os.Environment
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingSharedUrl: String? = null
    @Volatile private var pendingInstallFile: File? = null

    private val updateExecutor = Executors.newSingleThreadExecutor()
    private val updateHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val versionJsonUrl =
        "https://raw.githubusercontent.com/siraanabin/JET/main/version.json"

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Permission handled */ }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestRuntimePermissions()

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.addJavascriptInterface(JetNativeBridge(), "JetAndroid")

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pendingSharedUrl?.let { shared ->
                    sendUrlToWeb("onNativeSharedUrl", shared)
                    pendingSharedUrl = null
                }
                checkSystemClipboard()
            }
        }

        handleIncomingIntent(intent)
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ return window.handleAndroidBack ? window.handleAndroidBack() : false; })()"
                ) { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.postDelayed({ checkSystemClipboard() }, 350)
        }
        val waitingFile = pendingInstallFile
        if (waitingFile != null && canInstallPackages()) {
            pendingInstallFile = null
            installDownloadedApk(waitingFile)
        }
    }

    override fun onDestroy() {
        updateExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun currentVersionCode(): Long {
        val info = packageManager.getPackageInfo(packageName, 0)
        return PackageInfoCompat.getLongVersionCode(info)
    }

    private fun currentVersionName(): String {
        return packageManager.getPackageInfo(packageName, 0).versionName ?: "unknown"
    }

    private fun canInstallPackages(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            packageManager.canRequestPackageInstalls()
    }

    private fun sendJsCallback(functionName: String, vararg args: Any?) {
        if (!::webView.isInitialized || isFinishing || isDestroyed) return
        val jsonArgs = JSONArray()
        args.forEach { value -> jsonArgs.put(value) }
        runOnUiThread {
            if (!::webView.isInitialized || isFinishing || isDestroyed) return@runOnUiThread
            webView.evaluateJavascript(
                "if (window.$functionName) window.$functionName.apply(window, $jsonArgs);",
                null
            )
        }
    }

    private fun checkForAppUpdate(manual: Boolean) {
        updateExecutor.execute {
            try {
                val request = Request.Builder()
                    .url(versionJsonUrl)
                    .header("Cache-Control", "no-cache")
                    .build()
                updateHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("Version check failed (HTTP ${response.code})")
                    }
                    val body = response.body?.string()
                        ?: throw IOException("Empty version information")
                    val remote = JSONObject(body)
                    val remoteCode = remote.optLong("versionCode", -1L)
                    val remoteName = remote.optString("versionName", "")
                    val apkUrl = remote.optString("apkUrl", "")
                    val changelog = remote.optString("changelog", "")

                    if (remoteCode <= 0 || remoteName.isBlank() ||
                        !apkUrl.startsWith("https://")) {
                        throw IOException("Invalid version.json")
                    }

                    val installedCode = currentVersionCode()
                    val installedName = currentVersionName()
                    if (remoteCode > installedCode) {
                        sendJsCallback(
                            "onNativeAppUpdateAvailable",
                            remoteName,
                            changelog,
                            apkUrl
                        )
                    } else if (manual) {
                        sendJsCallback("onNativeAppUpdateNotAvailable", installedName)
                    }
                }
            } catch (error: Exception) {
                if (manual) {
                    sendJsCallback(
                        "onNativeAppUpdateError",
                        error.message ?: "Could not check for updates"
                    )
                }
            }
        }
    }

    private fun downloadAndInstallAppUpdate(apkUrl: String) {
        updateExecutor.execute {
            try {
                val uri = Uri.parse(apkUrl)
                if (uri.scheme != "https" || uri.host.isNullOrBlank()) {
                    throw IOException("Invalid APK download URL")
                }

                val updatesDir = File(cacheDir, "updates")
                if (!updatesDir.exists() && !updatesDir.mkdirs()) {
                    throw IOException("Could not create update cache")
                }
                val apkFile = File(updatesDir, "JET-update.apk")
                if (apkFile.exists()) apkFile.delete()

                val request = Request.Builder().url(apkUrl).build()
                updateHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("APK download failed (HTTP ${response.code})")
                    }
                    val body = response.body ?: throw IOException("Empty APK response")
                    val totalBytes = body.contentLength()
                    var downloaded = 0L
                    var lastReportedPercent = -1
                    body.byteStream().use { input ->
                        apkFile.outputStream().buffered().use { output ->
                            val buffer = ByteArray(16 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count == -1) break
                                output.write(buffer, 0, count)
                                downloaded += count
                                if (totalBytes > 0) {
                                    val percent = ((downloaded * 100L) / totalBytes)
                                        .toInt().coerceIn(0, 100)
                                    if (percent != lastReportedPercent) {
                                        lastReportedPercent = percent
                                        val label = String.format(
                                            java.util.Locale.US,
                                            "%.1f / %.1f MB",
                                            downloaded / 1048576.0,
                                            totalBytes / 1048576.0
                                        )
                                        sendJsCallback(
                                            "onNativeAppUpdateProgress",
                                            percent,
                                            label
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (!apkFile.exists() || apkFile.length() <= 0L) {
                    throw IOException("Downloaded APK is empty")
                }

                sendJsCallback("onNativeAppUpdateProgress", 100, "Download complete")
                runOnUiThread {
                    pendingInstallFile = apkFile
                    if (canInstallPackages()) {
                        pendingInstallFile = null
                        installDownloadedApk(apkFile)
                    } else {
                        Toast.makeText(
                            this,
                            "Allow JET to install unknown apps, then return here",
                            Toast.LENGTH_LONG
                        ).show()
                        val settingsIntent = Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(settingsIntent)
                    }
                }
            } catch (error: Exception) {
                sendJsCallback(
                    "onNativeAppUpdateError",
                    error.message ?: "APK download failed"
                )
            }
        }
    }

    private fun installDownloadedApk(apkFile: File) {
        try {
            val apkUri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(installIntent)
        } catch (error: Exception) {
            sendJsCallback(
                "onNativeAppUpdateError",
                error.message ?: "Could not open Android installer"
            )
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
            if (!sharedText.isNullOrEmpty()) {
                val extracted = extractFirstUrl(sharedText) ?: sharedText
                if (::webView.isInitialized && webView.url != null) {
                    sendUrlToWeb("onNativeSharedUrl", extracted)
                } else {
                    pendingSharedUrl = extracted
                }
            }
        }
    }

    private fun checkSystemClipboard() {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = clipboard?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
                val url = extractFirstUrl(text)
                if (url != null) {
                    sendUrlToWeb("onNativeClipboardUrl", url)
                }
            }
        } catch (_: Exception) {
            // Clipboard access restricted in background
        }
    }

    private fun extractFirstUrl(text: String): String? {
        val regex = Regex("(https?://[^\s]+)")
        return regex.find(text)?.value
    }

    private fun sendUrlToWeb(fnName: String, url: String) {
        val quoted = JSONObject.quote(url)
        webView.evaluateJavascript("if (window.$fnName) window.$fnName($quoted);", null)
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    inner class JetNativeBridge {

        @JavascriptInterface
        fun setStatusBarTheme(isDark: Boolean) {
            runOnUiThread {
                val window = this@MainActivity.window
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                if (isDark) {
                    window.statusBarColor = Color.parseColor("#090C14")
                    window.navigationBarColor = Color.parseColor("#0D121F")
                    controller.isAppearanceLightStatusBars = false
                    controller.isAppearanceLightNavigationBars = false
                } else {
                    window.statusBarColor = Color.parseColor("#F4F6FB")
                    window.navigationBarColor = Color.parseColor("#FFFFFF")
                    controller.isAppearanceLightStatusBars = true
                    controller.isAppearanceLightNavigationBars = true
                }
            }
        }

        @JavascriptInterface
        fun getClipboardUrl(): String {
            return try {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                val text = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
                extractFirstUrl(text) ?: ""
            } catch (_: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun enqueueSystemDownload(url: String, title: String, ext: String): Boolean {
            return try {
                val lower = url.lowercase()
                val isDirectFile = lower.endsWith(".mp4") || lower.endsWith(".mp3") ||
                    lower.endsWith(".m4a") || lower.endsWith(".pdf") || lower.endsWith(".webm")
                if (!isDirectFile) return false

                val safeName = title.replace(Regex("[^a-zA-Z0-9._-]"), "_") + "." + ext.lowercase()
                val request = DownloadManager.Request(Uri.parse(url))
                    .setTitle(title)
                    .setDescription("Downloading via JET")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "JET/$safeName")
                    .setAllowedOverMetered(true)

                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                true
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun shareText(title: String, text: String) {
            runOnUiThread {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(sendIntent, "Share via JET"))
            }
        }

        @JavascriptInterface
        fun checkForAppUpdate(isManual: Boolean) {
            this@MainActivity.checkForAppUpdate(isManual)
        }

        @JavascriptInterface
        fun downloadAndInstallAppUpdate(apkUrl: String) {
            this@MainActivity.downloadAndInstallAppUpdate(apkUrl)
        }

        @JavascriptInterface
        fun showToast(message: String) {
            runOnUiThread {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
