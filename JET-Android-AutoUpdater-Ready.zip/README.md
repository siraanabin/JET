# JET — Android project

## Automatic APK builds

- Pushes to `main` and pull requests build a debug APK.
- Pushing a version tag such as `v3.4.0` builds a **signed release APK** and publishes a GitHub Release asset named `JET-release.apk`.
- The debug APK is for testing only. Installable in-place updates must use the release signing key.

## GitHub Actions signing secrets

Add these four repository secrets under **Settings → Secrets and variables → Actions**:

- `ANDROID_KEYSTORE_BASE64` — Base64 text of the `.jks` keystore
- `ANDROID_KEY_ALIAS` — key alias
- `ANDROID_KEYSTORE_PASSWORD` — keystore password
- `ANDROID_KEY_PASSWORD` — key password

Never commit the keystore or its passwords. Keep a private backup of the keystore; all future releases must use this exact signing key.

## Publish a release

1. Update `versionCode` and `versionName` in `app/build.gradle.kts`.
2. Update `versionCode`, `versionName`, `apkUrl`, and `changelog` in the root `version.json`.
3. Make sure `apkUrl` uses the matching tag and asset name, for example `https://github.com/siraanabin/JET/releases/download/v3.4.1/JET-release.apk`.
4. Push the changes to `main`.
5. Create and push the matching tag, for example `git tag v3.4.1 && git push origin v3.4.1`.
6. Wait for **Build JET Android APK** to finish, then confirm the GitHub Release contains `JET-release.apk`.

The app checks `version.json` shortly after startup and when the user taps **Check for Updates**. It downloads the APK to its private cache, shows download progress, and opens Android's package installer. Android only accepts an in-place update when the new APK has the same application ID and signing certificate, and a higher `versionCode`.

## Current project version

- Application ID: `com.jet.downloader`
- `versionCode`: 340
- `versionName`: 3.4.0
